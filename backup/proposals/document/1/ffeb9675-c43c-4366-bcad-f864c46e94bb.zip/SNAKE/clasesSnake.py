import pygame
import sys
import random

pygame.font.init
tama = (600,600)
colores = {"fondo": (0,0,0), "comida": (200,0,0), "cuerpo": (0,0,200)}
cuerpo = []
posicionInicial = [30,30]
dimensionCuerpo = (30,30)
dimensionComida = (30,30)
desplazamiento = dimensionCuerpo[0]
banderaDesplazamiento = 0

class Cuerpo():
    def __init__(self, num=0): 
        self.num = num
        self.direccionCabeza = ["der"]
        self.rect = pygame.Rect(posicionInicial, dimensionCuerpo) #Rect

    def mover(self, bandera):
        if bandera == 1:
            self.rect.top -= desplazamiento
        elif bandera == 2:
            self.rect.right += desplazamiento
        elif bandera == 3:
            self.rect.top += desplazamiento
        elif bandera == 4:
            self.rect.left -= desplazamiento

    def dibujar(self, ventana):
        ventana.blit(self.imagenCabeza, self.rect)

    def pintar(self, ventana):
        ventana.fill(colores["fondo"], self.rect)

    def get_posicion(self):
        return self.rect

    def set_posicion(self, rect):
        self.rect = rect

    def get_num(self):
        return self.num

    def girar(self, bandera):   #NEW     
        if self.direccionCabeza[0] == "der":
            if bandera == 1:
                self.imagenCabeza = pygame.transform.rotate(self.imagenCabeza, 90)
                self.direccionCabeza[0] = "arr"
            if bandera == 3:
                self.imagenCabeza = pygame.transform.rotate(self.imagenCabeza, -90)
                self.direccionCabeza[0] = "aba"

        if self.direccionCabeza[0] == "izq":
            if bandera == 1:
                self.imagenCabeza = pygame.transform.rotate(self.imagenCabeza, -90)
                self.direccionCabeza[0] = "arr"
            if bandera == 3:
                self.imagenCabeza = pygame.transform.rotate(self.imagenCabeza, 90)
                self.direccionCabeza[0] = "aba"

        if self.direccionCabeza[0] == "arr":
            if bandera == 2:
                self.imagenCabeza = pygame.transform.rotate(self.imagenCabeza, -90)
                self.direccionCabeza[0] = "der"
            if bandera == 4:
                self.imagenCabeza = pygame.transform.rotate(self.imagenCabeza, 90)
                self.direccionCabeza[0] = "izq"

        if self.direccionCabeza[0] == "aba":
            if bandera == 2:
                self.imagenCabeza = pygame.transform.rotate(self.imagenCabeza, 90)
                self.direccionCabeza[0] = "der"
            if bandera == 4:
                self.imagenCabeza = pygame.transform.rotate(self.imagenCabeza, -90)
                self.direccionCabeza[0] = "izq"

class Cabeza(Cuerpo): #NEW
    def __init__(self):
        Cuerpo.__init__(self)
        self.imagenCabeza = pygame.image.load("cabeza.png")

    def come(self, comida):
        return self.rect.colliderect(comida.get_posicion())

    def choque(self, cuerpo):
        if self.rect.right > tama[0] or self.rect.left < 0 or self.rect.top < posicionInicial[0] or self.rect.bottom > tama[1]:
            return True
        if len(cuerpo) > 0:
            for parte in cuerpo:
                if parte.get_posicion().colliderect(self.rect):
                    return True
                    
class Parte(Cuerpo): #NEW
    def __init__(self):
        Cuerpo.__init__(self)
        self.imagenCabeza = pygame.image.load("cuerpoSnake.png")

class Comida():
    def __init__(self):
        self.imagenComida = pygame.image.load("manzana.png") #NEW 
        self.rect = pygame.Rect((random.randint(0,(tama[0]/dimensionComida[0])-1)*dimensionCuerpo[0],random.randint(0,(tama[1]/dimensionComida[1])-1)*dimensionCuerpo[0]),dimensionComida)        
    def dibujar(self, ventana):
        ventana.blit(self.imagenComida, self.rect) #NEW
        # ventana.fill(colores["comida"], self.rect)

    def redefinir_posicion(self):
        self.rect = pygame.Rect((random.randint(0,(tama[0]/dimensionComida[0])-1)*dimensionCuerpo[0],random.randint(0,(tama[1]/dimensionComida[1])-1)*dimensionCuerpo[0]),dimensionComida)

    def get_posicion(self):
        return self.rect

def reiniciar():
    global cuerpo
    cuerpo = []
    global banderaDesplazamiento
    banderaDesplazamiento = 0
    ventana.fill(colores["fondo"])
    rectAux = pygame.Rect(posicionInicial, dimensionCuerpo)
    cabeza.set_posicion(rectAux)
    cabeza.dibujar()
    comida.redefinir_posicion()
    comida.dibujar()