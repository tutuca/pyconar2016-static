from clasesSnake import *

class SceneBase:
    def __init__(self):
        self.next = self
    
    def ProcessInput(self, events, pressed_keys):
        print("METODO NO SOBREESCRITO :D")

    def Update(self):
        print("METODO NO SOBREESCRITO :D")

    def Render(self, screen):
        print("METODO NO SOBREESCRITO :D")

    def SwitchToScene(self, next_scene):
        self.next = next_scene
    
    def Terminate(self):
        self.SwitchToScene(None)

class TitleScene(SceneBase):
    def __init__(self):
        SceneBase.__init__(self)
        self.imagen = 0

    def ProcessInput(self, events, pressed_keys):
        for event in events:
            if event.type == pygame.KEYDOWN and event.key == pygame.K_RETURN:
                # Move to the next scene when the user pressed Enter
                self.SwitchToScene(GameScene())

    def Update(self):
        pass

    def Render(self, screen):
        # For the sake of brevity, the title scene is a blank red screen
        if self.imagen == 0:
            imagenPortada = pygame.image.load("portada.png")
            screen.blit(imagenPortada, (0,0))
            self.imagen = 1
        else:
            imagenPortada = pygame.image.load("portada2.png")
            screen.blit(imagenPortada, (0,0))
            self.imagen = 0


class GameScene(SceneBase):
    def __init__(self):
        SceneBase.__init__(self)
        self.cabeza = Cabeza()
        self.comida = Comida()
        self.cuerpo = []
        self.banderaDesplazamiento = 0
        self.puntaje = 0
        self.fuente = pygame.font.SysFont("Arial", 14)
    
    def ProcessInput(self, events, pressed_keys):
        for event in events:
            if event.type == pygame.KEYDOWN and event.key == pygame.K_RETURN:
                self.SwitchToScene(TitleScene())        	
            #UTILIZAR pressed_keys  (va a ser mas corto)
            if event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE:
                self.SwitchToScene(TitleScene())
            if event.type == pygame.KEYDOWN and event.key == pygame.K_UP and self.banderaDesplazamiento != 3:
                self.banderaDesplazamiento = 1                
            elif event.type == pygame.KEYDOWN and event.key == pygame.K_RIGHT and self.banderaDesplazamiento != 4:
                self.banderaDesplazamiento = 2
            elif event.type == pygame.KEYDOWN and event.key == pygame.K_DOWN and self.banderaDesplazamiento != 1:
                self.banderaDesplazamiento = 3
            elif event.type == pygame.KEYDOWN and event.key == pygame.K_LEFT and self.banderaDesplazamiento != 2:
                self.banderaDesplazamiento = 4
            self.cabeza.girar(self.banderaDesplazamiento)

    def Update(self):
        pass

    def Render(self, screen):
        #pintar fondo de color negro solo la primera vez
        if self.banderaDesplazamiento == 0:
            screen.fill((0, 0, 0))

        self.cabeza.dibujar(screen)
        #linea delimita score y vida
        pygame.draw.line(screen, (255,255,255), (0,28), (600,28))
        screen.fill((0,0,0), (0,0,600,25))
        miTexto = self.fuente.render(":.. Puntaje: " + str(self.puntaje) + " ..:", 0, (200,200,200))
        screen.blit(miTexto, (400,10))

        if self.banderaDesplazamiento != 0:
            posicionCabecaActual = pygame.Rect(self.cabeza.get_posicion())
            self.cabeza.pintar(screen)
            self.cabeza.mover(self.banderaDesplazamiento)
            self.cabeza.dibujar(screen)

            if self.cabeza.choque(self.cuerpo):
                self.reiniciar(screen)

            if self.cabeza.come(self.comida):
                self.puntaje += 1
                self.comida.redefinir_posicion()
                self.cuerpo.append(Parte())

            if len(self.cuerpo) > 0:
                self.cuerpo[0].pintar(screen) #pinta color de fondo
                self.cuerpo[0].girar(self.banderaDesplazamiento)  #NEW
                self.cuerpo[0].set_posicion(posicionCabecaActual)
                self.cuerpo[0].dibujar(screen)
                self.cuerpo.append(self.cuerpo[0])
                self.cuerpo.pop(0)
        self.comida.dibujar(screen)
        
    def reiniciar(self, ventana):
        self.cuerpo = []
        self.banderaDesplazamiento = 0
        self.puntaje = 0
        rectAux = pygame.Rect(posicionInicial, dimensionCuerpo)
        self.cabeza.set_posicion(rectAux)
        self.cabeza.dibujar(ventana)
        self.comida.redefinir_posicion()
        self.comida.dibujar(ventana)

def run_game(width, height, fps, starting_scene):
    pygame.init()
    screen = pygame.display.set_mode((width, height))
    #clock = pygame.time.Clock()

    active_scene = starting_scene

    while active_scene != None:
        pressed_keys = pygame.key.get_pressed()

        # Event filtering
        filtered_events = []
        for event in pygame.event.get():
            quit_attempt = False
            if event.type == pygame.QUIT:
                quit_attempt = True
            elif event.type == pygame.KEYDOWN:
                #el siguiente or es posible por pygame.key.get_pressed()
                #pressed_keys[pygame.K_LALT] devuelve 1 o 0
                alt_pressed = pressed_keys[pygame.K_LALT] or \
                              pressed_keys[pygame.K_RALT]
                if event.key == pygame.K_ESCAPE:
                    quit_attempt = True
                elif event.key == pygame.K_F4 and alt_pressed:
                    quit_attempt = True
                elif pressed_keys[pygame.K_u]:
                    fps += 10
                    print(fps)
                elif pressed_keys[pygame.K_j]:
                    fps -= 10
                    print(fps)

            if quit_attempt:
                active_scene.Terminate()
            else:
                filtered_events.append(event)

        active_scene.ProcessInput(filtered_events, pressed_keys)
        active_scene.Update()
        active_scene.Render(screen)

        active_scene = active_scene.next

        #pygame.display.flip()
        #clock.tick(fps)
        pygame.time.delay(fps)
        pygame.display.update()

# The rest is code where you implement your game using the Scenes model



run_game(600, 600, 200, TitleScene())