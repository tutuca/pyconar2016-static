Reveal.initialize({
    help: false,
    history: true
});