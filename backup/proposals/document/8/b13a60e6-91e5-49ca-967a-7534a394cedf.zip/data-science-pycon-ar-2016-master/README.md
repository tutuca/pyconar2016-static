# Slides for my talk at PyconAr 2016

## Data Science en Python: Una guía de proyectos y herramientas

Made using [reveal.js](https://github.com/hakimel/reveal.js).
